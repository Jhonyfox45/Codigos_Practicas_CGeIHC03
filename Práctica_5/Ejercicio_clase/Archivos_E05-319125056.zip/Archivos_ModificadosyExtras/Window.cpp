#include "Window.h"

Window::Window()
{
	width = 800;
	height = 600;
	for (size_t i = 0; i < 1024; i++)
	{
		keys[i] = 0;
	}
}
Window::Window(GLint windowWidth, GLint windowHeight)
{
	width = windowWidth;
	height = windowHeight;
	rotax = 0.0f;
	rotay = 0.0f;
	rotaz = 0.0f;
	articulacion1 = 0.0f;
	articulacion2 = 0.0f;
	articulacion3 = 0.0f;
	articulacion4 = 0.0f;
	articulacion5 = 0.0f;
	articulacion6 = 0.0f;
	//Definimos m�s articulaciones
	articulacion7 = 0.0f;
	articulacion8 = 0.0f;
	articulacion9 = 0.0f;
	articulacion10 = 0.0f;
	//Instanciamos las articuaciones faltantes
	articulacion11 = 0.0f;
	articulacion12 = 0.0f;
	articulacion13 = 0.0f;
	articulacion14 = 0.0f;
	articulacion15 = 0.0f;
	articulacion16 = 0.0f;
	articulacion17 = 0.0f;
	articulacion18 = 0.0f;
	//Las articulaciones de mi sonda (solamente 4)
	articulacionsonda1 = 0.0f;
	articulacionsonda2 = 0.0f;
	articulacionsonda3 = 0.0f;
	articulacionsonda4 = 0.0f;
	for (size_t i = 0; i < 1024; i++)
	{
		keys[i] = 0;
	}
}
int Window::Initialise()
{
	//Inicializaci�n de GLFW
	if (!glfwInit())
	{
		printf("Fall� inicializar GLFW");
		glfwTerminate();
		return 1;
	}
	//Asignando variables de GLFW y propiedades de ventana
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	//para solo usar el core profile de OpenGL y no tener retrocompatibilidad
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);

	//CREAR VENTANA
	mainWindow = glfwCreateWindow(width, height, "Practica XX: Nombre de la pr�ctica", NULL, NULL);

	if (!mainWindow)
	{
		printf("Fallo en crearse la ventana con GLFW");
		glfwTerminate();
		return 1;
	}
	//Obtener tama�o de Buffer
	glfwGetFramebufferSize(mainWindow, &bufferWidth, &bufferHeight);

	//asignar el contexto
	glfwMakeContextCurrent(mainWindow);

	//MANEJAR TECLADO y MOUSE
	createCallbacks();


	//permitir nuevas extensiones
	glewExperimental = GL_TRUE;

	if (glewInit() != GLEW_OK)
	{
		printf("Fall� inicializaci�n de GLEW");
		glfwDestroyWindow(mainWindow);
		glfwTerminate();
		return 1;
	}

	glEnable(GL_DEPTH_TEST); //HABILITAR BUFFER DE PROFUNDIDAD
							 // Asignar valores de la ventana y coordenadas
							 
							 //Asignar Viewport
	glViewport(0, 0, bufferWidth, bufferHeight);
	//Callback para detectar que se est� usando la ventana
	glfwSetWindowUserPointer(mainWindow, this);
}

void Window::createCallbacks()
{
	glfwSetKeyCallback(mainWindow, ManejaTeclado);
	glfwSetCursorPosCallback(mainWindow, ManejaMouse);
}

GLfloat Window::getXChange()
{
	GLfloat theChange = xChange;
	xChange = 0.0f;
	return theChange;
}

GLfloat Window::getYChange()
{
	GLfloat theChange = yChange;
	yChange = 0.0f;
	return theChange;
}

void Window::ManejaTeclado(GLFWwindow* window, int key, int code, int action, int mode)
{
	Window* theWindow = static_cast<Window*>(glfwGetWindowUserPointer(window));

	if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(window, GL_TRUE);
	}

	
	if (key == GLFW_KEY_E)
	{
		theWindow->rotax += 10.0;
	}
	if (key == GLFW_KEY_R)
	{
		theWindow->rotay += 10.0; //rotar sobre el eje y 10 grados
	}
	if (key == GLFW_KEY_T)
	{
		theWindow->rotaz += 10.0;
	}
	//Modificamos la distribuci�n de las teclas
	if (key == GLFW_KEY_Y)
	{
		theWindow->articulacion1 += 10.0;
	}

	if (key == GLFW_KEY_U)
	{
		theWindow->articulacion2 += 10.0;
	}
	if (key == GLFW_KEY_I)
	{
		theWindow->articulacion3 += 10.0;
	}
	if (key == GLFW_KEY_O)
	{
		theWindow->articulacion4 += 10.0;
	}
	//Logica del tope en grados usando dos teclas para aumentar o disminuir el angulo
	if (key == GLFW_KEY_F)
	{
		if (theWindow->articulacion5 < 45.0f) {
			theWindow->articulacion5 += 1.0;
		}
	}
	if (key == GLFW_KEY_G)
	{
		if (theWindow->articulacion5 > -45) {
			theWindow->articulacion5 -= 1.0;
		}
	}
	if (key == GLFW_KEY_H)
	{
		if (theWindow->articulacion6 < 45.0f) {
			theWindow->articulacion6 += 1.0;
		}
	}
	if (key == GLFW_KEY_J)
	{
		if (theWindow->articulacion6 > -45) {
			theWindow->articulacion6 -= 1.0;
		}
	}
	if (key == GLFW_KEY_K)
	{
		if (theWindow->articulacion7 < 45.0f) {
			theWindow->articulacion7 += 1.0;
		}
	}
	if (key == GLFW_KEY_L)
	{
		if (theWindow->articulacion7 > -45) {
			theWindow->articulacion7 -= 1.0;
		}
	}
	if (key == GLFW_KEY_Z)
	{
		if (theWindow->articulacion8 < 45.0f) {
			theWindow->articulacion8 += 1.0;
		}
	}
	if (key == GLFW_KEY_X)
	{
		if (theWindow->articulacion8 > -45) {
			theWindow->articulacion8 -= 1.0;
		}
	}
	if (key == GLFW_KEY_C)
	{
		if (theWindow->articulacion9 < 45.0f) {
			theWindow->articulacion9 += 1.0;
		}
	}
	if (key == GLFW_KEY_V)
	{
		if (theWindow->articulacion9 > -45) {
			theWindow->articulacion9 -= 1.0;
		}
	}
	if (key == GLFW_KEY_B)
	{
		if (theWindow->articulacion10 < 45.0f) {
			theWindow->articulacion10 += 1.0;
		}
	}
	if (key == GLFW_KEY_N)
	{
		if (theWindow->articulacion10 > -45) {
			theWindow->articulacion10 -= 1.0;
		}
	}
	if (key == GLFW_KEY_M)
	{
		theWindow->articulacion17 += 10.0;
	}
	if (key == GLFW_KEY_COMMA)
	{
		theWindow->articulacion18 += 10.0;
	}
	//Los 4 if para las bisagras de la sonda
	if (key == GLFW_KEY_1)
	{
		theWindow->articulacionsonda1 += 10.0;
	}
	if (key == GLFW_KEY_2)
	{
		theWindow->articulacionsonda2 += 10.0;
	}
	if (key == GLFW_KEY_3)
	{
		theWindow->articulacionsonda3 += 10.0;
	}
	if (key == GLFW_KEY_4)
	{
		theWindow->articulacionsonda4 += 10.0;
	}

	if (key == GLFW_KEY_D && action == GLFW_PRESS)
	{
		const char* key_name = glfwGetKeyName(GLFW_KEY_D, 0);
		//printf("se presiono la tecla: %s\n",key_name);
	}

	if (key >= 0 && key < 1024)
	{
		if (action == GLFW_PRESS)
		{
			theWindow->keys[key] = true;
			//printf("se presiono la tecla %d'\n", key);
		}
		else if (action == GLFW_RELEASE)
		{
			theWindow->keys[key] = false;
			//printf("se solto la tecla %d'\n", key);
		}
	}
}

void Window::ManejaMouse(GLFWwindow* window, double xPos, double yPos)
{
	Window* theWindow = static_cast<Window*>(glfwGetWindowUserPointer(window));

	if (theWindow->mouseFirstMoved)
	{
		theWindow->lastX = xPos;
		theWindow->lastY = yPos;
		theWindow->mouseFirstMoved = false;
	}

	theWindow->xChange = xPos - theWindow->lastX;
	theWindow->yChange = theWindow->lastY - yPos;

	theWindow->lastX = xPos;
	theWindow->lastY = yPos;
}


Window::~Window()
{
	glfwDestroyWindow(mainWindow);
	glfwTerminate();

}
